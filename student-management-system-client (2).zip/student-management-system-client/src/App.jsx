

function App() {
  
  return (
    <>
      <h3 className='text-4xl font-bold text-sky-400 uppercase text-center'>Welcome to student management system</h3>
        <button className="btn btn-secondary">Click</button>
    </>
  )
}

export default App
