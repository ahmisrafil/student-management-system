import NavBar from "../../Layout/NavBar";
import HomeInterface from "./Home/HomeInterface";


const Home = () => {
    return (
        <div className="h-[100vh]">
        
        <HomeInterface></HomeInterface>
        
      </div>
    );
};

export default Home;

